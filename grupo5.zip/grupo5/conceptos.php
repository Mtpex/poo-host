<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POO en PHP - Conceptos Básicos</title>
    <link rel="stylesheet" type="text/css" href="./css/style.css?v=300.0">
</head>
<body>

    <header class="header-banner">
        <img src="./img/banner.jpg" alt="Programación Orientada a Objetos en PHP - 3ro A Informática">
    </header>

    <nav>
        <a href="index.php">Inicio</a>
        <a href="conceptos.php" class="activo">Conceptos Básicos</a>
        <a href="estructura.php">Estructura</a>
        <a href="pilares.php">Pilares</a>
        <a href="practica.php">Ejemplo Práctico</a>
        <a href="evaluacion.php">Evaluación</a>
    </nav>

    <div class="container">
        <div class="banner">
            <h2>Conceptos Básicos: ¿Qué es la POO?</h2>
            <p>Bases teóricas del paradigma de desarrollo orientado a objetos en PHP.</p>
        </div>

        <div class="rejilla">
            <div class="tarjeta">
                <h3>Definición del Paradigma</h3>
                <p>La <strong>Programación Orientada a Objetos (POO)</strong> es un modelo de programación que organiza el diseño del software alrededor de datos u objetos, en lugar de funciones y lógica pura. Cada objeto representa una entidad del mundo real con sus propias características y comportamientos.</p>
            </div>

            <div class="tarjeta">
                <h3>Ventajas en el Desarrollo Web</h3>
                <ul>
                    <li><strong>Reutilización de código:</strong> Permite utilizar clases ya programadas en múltiples módulos del sistema.</li>
                    <li><strong>Mantenibilidad:</strong> Si se necesita corregir un comportamiento, solo se modifica la clase correspondiente.</li>
                    <li><strong>Escalabilidad:</strong> Facilita añadir nuevas funcionalidades sin alterar la lógica existente.</li>
                </ul>
            </div>

            <div class="tarjeta">
                <h3>Programación Estructurada vs POO</h3>
                <p>En el modelo estructurado, los datos y las funciones viajan por separado y pueden ser modificados de forma global. En POO, los atributos y los métodos coexisten protegidos dentro de la misma clase, evitando inconsistencias en la memoria.</p>
            </div>
        </div>
    </div>

    <footer>
        <p>Unidad Educativa Fiscomisional María Auxiliadora - Bachillerato en Informática</p>
    </footer>

</body>
</html>