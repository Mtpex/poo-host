<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POO en PHP - Estructura</title>
    <link rel="stylesheet" type="text/css" href="./css/style.css?v=300.0">
</head>
<body>

    <header class="header-banner">
        <img src="./img/banner.jpg" alt="Programación Orientada a Objetos en PHP - 3ro A Informática">
    </header>

    <nav>
        <a href="index.php">Inicio</a>
        <a href="conceptos.php">Conceptos Básicos</a>
        <a href="estructura.php" class="activo">Estructura</a>
        <a href="pilares.php">Pilares</a>
        <a href="practica.php">Ejemplo Práctico</a>
        <a href="evaluacion.php">Evaluación</a>
    </nav>

    <div class="container">
        <div class="banner">
            <h2>Estructura Fundamental en PHP</h2>
            <p>Elementos sintácticos esenciales para construir programas orientados a objetos.</p>
        </div>

        <div class="rejilla">
            <div class="tarjeta">
                <h3>a. Clases y Objetos</h3>
                <p><strong>Clase:</strong> Plantilla donde se declaran las variables (atributos) y funciones (métodos).</p>
                <p><strong>Objeto:</strong> Instancia en memoria creada a partir de una clase mediante la palabra reservada <code>new</code>.</p>
            </div>

            <div class="tarjeta">
                <h3>b. Atributos y Métodos</h3>
                <p><strong>Atributos:</strong> Variables internas que guardan las propiedades o el estado del objeto.</p>
                <p><strong>Métodos:</strong> Funciones que definen las acciones u operaciones que el objeto puede ejecutar.</p>
            </div>

            <div class="tarjeta">
                <h3>c. Método Constructor y $this</h3>
                <p><strong>__construct():</strong> Método mágico que se dispara automáticamente al instanciar un objeto para inicializar sus atributos.</p>
                <p><strong>$this:</strong> Pseudo-variable que hace referencia a la instancia del objeto actual en ejecución.</p>
            </div>

            <div class="tarjeta">
                <h3>Ejemplo Integrador en PHP</h3>
                <pre>&lt;?php
class Vehiculo {
    public $marca;
    public $color;

    // Constructor para asignar valores iniciales con $this
    public function __construct($marca, $color) {
        $this->marca = $marca;
        $this->color = $color;
    }

    // Metodo de accion
    public function encender() {
        return "El vehiculo " . $this->marca . " de color " . $this->color . " esta en marcha.";
    }
}

// Instanciacion de un objeto
$miAuto = new Vehiculo("Toyota", "Gris");

// Ejecucion del metodo
echo $miAuto->encender();
?&gt;</pre>
            </div>
        </div>
    </div>

    <footer>
        <p>Unidad Educativa Fiscomisional María Auxiliadora - Bachillerato en Informática</p>
    </footer>

</body>
</html>