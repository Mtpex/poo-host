<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POO en PHP - Evaluación</title>
    <link rel="stylesheet" type="text/css" href="./css/style.css?v=410.0">
</head>
<body>

    <header class="header-banner">
        <img src="./img/banner.jpg" alt="Programación Orientada a Objetos en PHP - 3ro A Informática">
    </header>

    <nav>
        <a href="index.php">Inicio</a>
        <a href="conceptos.php">Conceptos Básicos</a>
        <a href="estructura.php">Estructura</a>
        <a href="pilares.php">Pilares</a>
        <a href="practica.php">Ejemplo Práctico</a>
        <a href="evaluacion.php" class="activo">Evaluación</a>
    </nav>

    <div class="container">
        <div class="banner">
            <h2>Cuestionario de Evaluación (10 Preguntas)</h2>
            <p>Selecciona la opción correcta en cada una de las interrogantes. Cada acierto equivale a 1 punto sobre 10.</p>
        </div>

        <form method="POST" action="evaluacion.php" class="caja-formulario">

            <!-- PREGUNTA 1 -->
            <div class="pregunta">
                <p>1. ¿Con qué palabra reservada se crea una instancia u objeto a partir de una clase en PHP?</p>
                <label class="opcion"><input type="radio" name="p1" value="a" required> function</label>
                <label class="opcion"><input type="radio" name="p1" value="b"> new</label>
                <label class="opcion"><input type="radio" name="p1" value="c"> class</label>
            </div>

            <!-- PREGUNTA 2 -->
            <div class="pregunta">
                <p>2. ¿Qué método especial se ejecuta automáticamente al instanciar un objeto?</p>
                <label class="opcion"><input type="radio" name="p2" value="a" required> __construct()</label>
                <label class="opcion"><input type="radio" name="p2" value="b"> __destruct()</label>
                <label class="opcion"><input type="radio" name="p2" value="c"> __init()</label>
            </div>

            <!-- PREGUNTA 3 -->
            <div class="pregunta">
                <p>3. ¿Para qué se utiliza la pseudo-variable $this dentro de una clase?</p>
                <label class="opcion"><input type="radio" name="p3" value="a" required> Para conectar el script a la base de datos MySQL</label>
                <label class="opcion"><input type="radio" name="p3" value="b"> Para referenciar al objeto actual que ejecuta el código</label>
                <label class="opcion"><input type="radio" name="p3" value="c"> Para crear una copia estática de la clase</label>
            </div>

            <!-- PREGUNTA 4 -->
            <div class="pregunta">
                <p>4. ¿Qué son los atributos en una clase?</p>
                <label class="opcion"><input type="radio" name="p4" value="a" required> Variables internas que almacenan las propiedades y estado del objeto</label>
                <label class="opcion"><input type="radio" name="p4" value="b"> Funciones que ejecutan acciones operativas</label>
                <label class="opcion"><input type="radio" name="p4" value="c"> Comentarios de documentación en el código</label>
            </div>

            <!-- PREGUNTA 5 -->
            <div class="pregunta">
                <p>5. ¿Qué son los métodos en una clase?</p>
                <label class="opcion"><input type="radio" name="p5" value="a" required> Nombres reservados para crear archivos PHP</label>
                <label class="opcion"><input type="radio" name="p5" value="b"> Funciones internas que definen el comportamiento de los objetos</label>
                <label class="opcion"><input type="radio" name="p5" value="c"> Etiquetas de diseño de hojas de estilo</label>
            </div>

            <!-- PREGUNTA 6 -->
            <div class="pregunta">
                <p>6. ¿Qué pilar de la POO permite reutilizar código de una clase padre usando la palabra <em>extends</em>?</p>
                <label class="opcion"><input type="radio" name="p6" value="a" required> Polimorfismo</label>
                <label class="opcion"><input type="radio" name="p6" value="b"> Encapsulamiento</label>
                <label class="opcion"><input type="radio" name="p6" value="c"> Herencia</label>
            </div>

            <!-- PREGUNTA 7 -->
            <div class="pregunta">
                <p>7. ¿Qué modificador de visibilidad impide que un atributo sea modificado o leído directamente fuera de la clase?</p>
                <label class="opcion"><input type="radio" name="p7" value="a" required> public</label>
                <label class="opcion"><input type="radio" name="p7" value="b"> private</label>
                <label class="opcion"><input type="radio" name="p7" value="c"> global</label>
            </div>

            <!-- PREGUNTA 8 -->
            <div class="pregunta">
                <p>8. ¿Qué pilar de la POO describe la capacidad de que diferentes clases respondan a un mismo método de maneras distintas?</p>
                <label class="opcion"><input type="radio" name="p8" value="a" required> Polimorfismo</label>
                <label class="opcion"><input type="radio" name="p8" value="b"> Modularidad</label>
                <label class="opcion"><input type="radio" name="p8" value="c"> Instanciación</label>
            </div>

            <!-- PREGUNTA 9 -->
            <div class="pregunta">
                <p>9. ¿Qué palabra clave se usa para definir una clase que no se puede instanciar directamente y sirve de molde estricto?</p>
                <label class="opcion"><input type="radio" name="p9" value="a" required> static</label>
                <label class="opcion"><input type="radio" name="p9" value="b"> abstract</label>
                <label class="opcion"><input type="radio" name="p9" value="c"> final</label>
            </div>

            <!-- PREGUNTA 10 -->
            <div class="pregunta">
                <p>10. ¿Cuál es el operador utilizado en PHP para acceder a los atributos y métodos de un objeto instanciado?</p>
                <label class="opcion"><input type="radio" name="p10" value="a" required> El punto (.)</label>
                <label class="opcion"><input type="radio" name="p10" value="b"> La flecha (-&gt;)</label>
                <label class="opcion"><input type="radio" name="p10" value="c"> Los dos puntos (::)</label>
            </div>

            <button type="submit" class="btn">Calificar Evaluación</button>

            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $respuestasCorrectas = [
                    'p1'  => 'b',
                    'p2'  => 'a',
                    'p3'  => 'b',
                    'p4'  => 'a',
                    'p5'  => 'b',
                    'p6'  => 'c',
                    'p7'  => 'b',
                    'p8'  => 'a',
                    'p9'  => 'b',
                    'p10' => 'b'
                ];

                $aciertos = 0;
                foreach ($respuestasCorrectas as $pregunta => $correcta) {
                    if (isset($_POST[$pregunta]) && $_POST[$pregunta] === $correcta) {
                        $aciertos++;
                    }
                }

                $calificacion = $aciertos; // 1 punto por acierto = sobre 10

                echo '<div class="resultado">';
                echo '<h3>Resultado de la Evaluación</h3>';
                echo '<p><strong>Aciertos:</strong> ' . $aciertos . ' de 10 preguntas correctas.</p>';
                echo '<p><strong>Calificación Final:</strong> ' . number_format($calificacion, 1) . ' / 10</p>';
                
                if ($calificacion >= 7) {
                    echo '<p style="color: #2b573d; font-weight: bold; margin-top: 6px;">¡Aprobado! Tienes un excelente dominio de los fundamentos de POO en PHP.</p>';
                } else {
                    echo '<p style="color: #842029; font-weight: bold; margin-top: 6px;">Puntaje menor a 7. Te sugerimos repasar las secciones de Conceptos, Estructura y Pilares.</p>';
                }
                echo '</div>';
            }
            ?>
        </form>
    </div>

    <footer>
        <p>Unidad Educativa Fiscomisional María Auxiliadora - Bachillerato en Informática</p>
    </footer>

</body>
</html>