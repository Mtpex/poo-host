<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POO en PHP - Inicio</title>
    <link rel="stylesheet" type="text/css" href="./css/style.css?v=300.0">
</head>
<body>

    <header class="header-banner">
        <img src="./img/banner.jpg" alt="Programación Orientada a Objetos en PHP - 3ro A Informática">
    </header>

    <nav>
        <a href="index.php" class="activo">Inicio</a>
        <a href="conceptos.php">Conceptos Básicos</a>
        <a href="estructura.php">Estructura</a>
        <a href="pilares.php">Pilares</a>
        <a href="practica.php">Ejemplo Práctico</a>
        <a href="evaluacion.php">Evaluación</a>
    </nav>

    <div class="container">
        <div class="rejilla">
            <div class="tarjeta">
                <h3>Presentación del Proyecto</h3>
                <p>Proyecto académico interactivo para la exposición de Programación Orientada a Objetos en PHP.</p>
            </div>

            <div class="tarjeta">
                <h3>Integrantes (Equipo 5)</h3>
                <ul>
                    <li>Angel Angulo Bautista</li>
                    <li>Tiago Salazar Nazareno </li>
                    <li>Flor Chochos Bautista</li>
                    <li>Tiago Salazar Nazareno</li>
                    <li>Mateo Cisneros Solano</li>
                </ul>
            </div>

            <div class="tarjeta">
                <h3>Datos Informativos</h3>
                <p><strong>Materia:</strong> Programación y Base de Datos III</p>
                <p><strong>Docente:</strong> Ing. Patricia Saldarreaga R.</p>
                <p><strong>Curso:</strong> 3.° Bachillerato en Informática "A"</p>
            </div>
        </div>
    </div>

    <footer>
        <p>Unidad Educativa Fiscomisional María Auxiliadora - Bachillerato en Informática</p>
    </footer>

</body>
</html>