<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POO en PHP - 4 Pilares</title>
    <link rel="stylesheet" type="text/css" href="./css/style.css?v=300.0">
</head>
<body>

    <header class="header-banner">
        <img src="./img/banner.jpg" alt="Programación Orientada a Objetos en PHP - 3ro A Informática">
    </header>

    <nav>
        <a href="index.php">Inicio</a>
        <a href="conceptos.php">Conceptos Básicos</a>
        <a href="estructura.php">Estructura</a>
        <a href="pilares.php" class="activo">Pilares</a>
        <a href="practica.php">Ejemplo Práctico</a>
        <a href="evaluacion.php">Evaluación</a>
    </nav>

    <div class="container">
        <div class="banner">
            <h2>Los Cuatro Pilares de la POO</h2>
            <p>Principios arquitectónicos para estructurar código modular, protegido y reutilizable.</p>
        </div>

        <div class="rejilla">
            <!-- 1. ENCAPSULAMIENTO -->
            <div class="tarjeta">
                <h3>1. Encapsulamiento</h3>
                <p>Protege los datos internos declarándolos como <code>private</code> o <code>protected</code>, permitiendo su acceso o cambio únicamente mediante métodos controlados (getters y setters).</p>
                <pre>&lt;?php
class Usuario {
    private $nombre;
    private $clave;

    public function __construct($nom, $pass) {
        $this->nombre = $nom;
        $this->clave = $pass;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function cambiarClave($nuevaClave) {
        if (strlen($nuevaClave) &gt;= 4) {
            $this->clave = $nuevaClave;
            return "Clave actualizada con exito.";
        }
        return "Error: Clave demasiado corta.";
    }
}

$user = new Usuario("Mateo", "1234");
echo $user->getNombre();
echo $user->cambiarClave("abcd");
?&gt;</pre>
            </div>

            <!-- 2. HERENCIA -->
            <div class="tarjeta">
                <h3>2. Herencia</h3>
                <p>Permite que una clase hija adquiera atributos y métodos de una clase padre usando <strong>extends</strong>, evitando duplicar código.</p>
                <pre>&lt;?php
class Persona {
    public $nombre;
    public $cedula;

    public function __construct($nom, $ci) {
        $this->nombre = $nom;
        $this->cedula = $ci;
    }

    public function presentarse() {
        return "Nombre: " . $this->nombre . " | CI: " . $this->cedula;
    }
}

class Empleado extends Persona {
    public $sueldo;

    public function __construct($nom, $ci, $salario) {
        parent::__construct($nom, $ci);
        $this->sueldo = $salario;
    }

    public function verSueldo() {
        return $this->presentarse() . " | Sueldo: $" . $this->sueldo;
    }
}

$emp = new Empleado("Tiago", "0850123456", 550);
echo $emp->verSueldo();
?&gt;</pre>
            </div>

            <!-- 3. POLIMORFISMO -->
            <div class="tarjeta">
                <h3>3. Polimorfismo</h3>
                <p>Permite que diferentes clases hijas respondan a un mismo nombre de método pero ejecutando una lógica personalizada según su contexto.</p>
                <pre>&lt;?php
class Notificacion {
    public function enviar($mensaje) {
        return "Notificacion base: " . $mensaje;
    }
}

class CorreoElectronico extends Notificacion {
    public function enviar($mensaje) {
        return "Enviando por Correo Electronico: " . $mensaje;
    }
}

class MensajeSMS extends Notificacion {
    public function enviar($mensaje) {
        return "Enviando mensaje de texto SMS: " . $mensaje;
    }
}

$notif1 = new CorreoElectronico();
$notif2 = new MensajeSMS();

echo $notif1->enviar("Reporte listo.");
echo $notif2->enviar("Codigo: 5678.");
?&gt;</pre>
            </div>

            <!-- 4. ABSTRACCIÓN -->
            <div class="tarjeta">
                <h3>4. Abstracción</h3>
                <p>Aísla la complejidad interna y obliga a las subclases a definir métodos esenciales usando clases abstractas (<code>abstract</code>).</p>
                <pre>&lt;?php
abstract class MetodoPago {
    protected $monto;

    public function __construct($valor) {
        $this->monto = $valor;
    }

    abstract public function procesarPago();
}

class PagoEfectivo extends MetodoPago {
    public function procesarPago() {
        return "Pago de $" . $this->monto . " cobrado en efectivo.";
    }
}

class PagoTarjeta extends MetodoPago {
    public function procesarPago() {
        $total = $this->monto * 1.05;
        return "Pago con tarjeta: $" . $total . " (incluye 5% de recargo).";
    }
}

$cobro = new PagoTarjeta(100);
echo $cobro->procesarPago();
?&gt;</pre>
            </div>
        </div>
    </div>

    <footer>
        <p>Unidad Educativa Fiscomisional María Auxiliadora - Bachillerato en Informática</p>
    </footer>

</body>
</html>