<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POO en PHP - Ejemplo Práctico</title>
    <link rel="stylesheet" type="text/css" href="./css/style.css?v=300.0">
</head>
<body>

    <header class="header-banner">
        <img src="./img/banner.jpg" alt="Programación Orientada a Objetos en PHP - 3ro A Informática">
    </header>

    <nav>
        <a href="index.php">Inicio</a>
        <a href="conceptos.php">Conceptos Básicos</a>
        <a href="estructura.php">Estructura</a>
        <a href="pilares.php">Pilares</a>
        <a href="practica.php" class="activo">Ejemplo Práctico</a>
        <a href="evaluacion.php">Evaluación</a>
    </nav>

    <div class="container">
        <div class="banner">
            <h2>Simulación Bancaria Interactiva</h2>
            <p>Demostración práctica de clases, métodos, constructor y encapsulamiento procesados mediante PHP en el servidor.</p>
        </div>

        <div class="caja-formulario">
            <form method="POST" action="practica.php">
                <div class="campo">
                    <label for="titular">Nombre del Titular:</label>
                    <input type="text" id="titular" name="titular" required placeholder="Ej. Mateo Cisneros">
                </div>

                <div class="campo">
                    <label for="saldo_inicial">Saldo Inicial ($):</label>
                    <input type="number" id="saldo_inicial" name="saldo_inicial" step="0.01" min="0" required placeholder="Ej. 100.00">
                </div>

                <div class="campo">
                    <label for="operacion">Operación a Realizar:</label>
                    <select id="operacion" name="operacion">
                        <option value="depositar">Depositar dinero</option>
                        <option value="retirar">Retirar dinero</option>
                    </select>
                </div>

                <div class="campo">
                    <label for="monto">Monto de la Operación ($):</label>
                    <input type="number" id="monto" name="monto" step="0.01" min="0.01" required placeholder="Ej. 25.00">
                </div>

                <button type="submit" class="btn">Procesar Transacción</button>
            </form>

            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                class CuentaBancaria {
                    private $titular;
                    private $saldo;

                    public function __construct($titular, $saldoInicial) {
                        $this->titular = htmlspecialchars($titular);
                        $this->saldo = floatval($saldoInicial);
                    }

                    public function depositar($monto) {
                        $this->saldo += floatval($monto);
                        return "Depósito exitoso de $" . number_format($monto, 2);
                    }

                    public function retirar($monto) {
                        $monto = floatval($monto);
                        if ($monto <= $this->saldo) {
                            $this->saldo -= $monto;
                            return "Retiro exitoso de $" . number_format($monto, 2);
                        } else {
                            return "Error: Fondos insuficientes para retirar $" . number_format($monto, 2);
                        }
                    }

                    public function getTitular() {
                        return $this->titular;
                    }

                    public function getSaldo() {
                        return number_format($this->saldo, 2);
                    }
                }

                $titular = $_POST['titular'] ?? '';
                $saldoInicial = $_POST['saldo_inicial'] ?? 0;
                $operacion = $_POST['operacion'] ?? '';
                $monto = $_POST['monto'] ?? 0;

                $cuenta = new CuentaBancaria($titular, $saldoInicial);

                if ($operacion === 'depositar') {
                    $mensaje = $cuenta->depositar($monto);
                } else {
                    $mensaje = $cuenta->retirar($monto);
                }

                echo '<div class="resultado">';
                echo '<h3>Resultado de la Operación</h3>';
                echo '<p><strong>Titular:</strong> ' . $cuenta->getTitular() . '</p>';
                echo '<p><strong>Estado:</strong> ' . $mensaje . '</p>';
                echo '<p><strong>Saldo Final Disponible:</strong> $' . $cuenta->getSaldo() . '</p>';
                echo '</div>';
            }
            ?>
        </div>
    </div>

    <footer>
        <p>Unidad Educativa Fiscomisional María Auxiliadora - Bachillerato en Informática</p>
    </footer>

</body>
</html>